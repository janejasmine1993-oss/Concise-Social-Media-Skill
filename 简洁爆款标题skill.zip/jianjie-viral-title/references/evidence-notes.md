# 依据与证据边界

更新日期：2026-09-16

本文件用于区分“可核验平台规则”“开源项目业务结构”和“第一版启发式”。平台规则会变化，使用高风险功能前应重新核验官方页面。

## 平台公开信息

### B站

- B站创作中心曾明确说明：标签默认同步为话题，默认取前三个选中或创建的标签；简介虽非必填，但鼓励填写。来源：[Web 投稿改版说明](https://www.bilibili.com/opus/127210875404901820)
- B站社区公约强调基于真实信息表达观点，禁止抄袭、捏造、造谣和有意误导。来源：[B站社区公约](https://member.bilibili.com/studio/convention/)
- 特定内容可添加创作者声明；转载应添加来源；涉及国内外时事、公共政策、社会事件等内容时，官方公告要求补充相关信息。来源：[主动添加内容标识公告](https://www.bilibili.com/opus/840812291428450327)

### 小红书

- 小红书公开页面可确认笔记搜索、搜索推荐词、热搜词、品牌词、品类词和话题聚合等入口存在，因此第一版将“核心搜索词 + 长尾场景词”作为标题与标签的重要检索维度。来源：[小红书 Deeplink 搜索说明](https://pages.xiaohongshu.com/activity/deeplink)
- 热议话题内容受平台服务协议和社区规范治理。来源：[小红书热议话题标签说明](https://fe.xiaohongshu.com/ditto/vincent/b9ca419956094c3aafaa7c2354aff1c8?fullscreen=true&naviHidden=yes&source=wowcard)

### 抖音

- 发布页存在作品描述和话题标签入口；第一版据此将描述和标签视为内容语义分类信息，但不声称它们决定推荐结果。
- 抖音公开网页和创作者材料分散，第一版关于“前半段快速理解、口播感、标题与视频前几秒一致”的规则属于短视频消费场景启发式，需要用用户账号数据校准。

### 微信公众号

- 第一版把第三项输出定义为“推荐话题/关键词”，而非声称 hashtag 是公众号核心分发机制。
- 标题、摘要与搜一搜的具体展现规则可能随版本和账号能力变化；上线使用前应以微信公众平台当时的编辑器与规则中心为准。

## 借鉴的开源业务结构

- [kangarooking/viral-title](https://github.com/kangarooking/kangarooking-skills/tree/main/viral-title)：通用方法、平台文件、标题库检索和反馈进化分层。
- [redfox xiaohongshu-creator](https://github.com/redfox-data/redfox-community-dsh/tree/main/skills/xiaohongshu-creator)：近期样本检索、生成与评分分路由、六维评分和参考证据链。
- [content-engine](https://github.com/2GT-Media-Group-LLC/content-engine)：采集、聚类、生成、人工 fate、发布后 post-mortem 的学习闭环。
- [buzz-title-generator](https://github.com/ai-business-lab/buzz-title-generator)：结构化 Brief、生成与评价分离、候选结构校验和多维评分。
- [mediacrawler](https://github.com/Authurzk/mediacrawler)：平台 Adapter、并行采集、规则过滤、LLM 去重排序和多格式导出。

## 第一版启发式，不是官方算法

以下内容均为待测试假设：

- 各平台的建议标题长度。
- 各标题机制的相对优先级。
- 描述建议字数和标签数量。
- 通用分与平台分的权重。
- 某个词、句式或 emoji 对点击/完播/收藏的影响。

输出时不得将这些启发式称为“官方推荐机制”“内部算法”或“CTR 预测”。只有接入真实曝光、点击/播放、完播、收藏、评论、分享数据后，才可以做账号级回测与权重校准。
