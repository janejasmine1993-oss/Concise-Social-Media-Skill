#!/usr/bin/env python3
"""Validate structured output from multi-platform-viral-title."""

from __future__ import annotations

import json
import sys
from pathlib import Path


RULES = {
    "douyin": {"title_max": 30, "desc_min": 20, "tags": (3, 6)},
    "xiaohongshu": {"title_max": 20, "desc_min": 30, "tags": (5, 8)},
    "bilibili": {"title_max": 40, "desc_min": 30, "tags": (5, 10)},
    "wechat_public_account": {"title_max": 36, "desc_min": 25, "tags": (3, 5)},
}

RISKY = ("100%", "百分百", "保证", "唯一", "全网第一", "永久", "绝对")


def text_len(value: str) -> int:
    return len("".join(value.split()))


def validate(path: Path) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"无法读取 JSON：{exc}"], warnings

    platforms = data.get("platforms")
    if not isinstance(platforms, list) or not platforms:
        return ["platforms 必须是非空数组"], warnings

    seen_platforms: set[str] = set()
    for p_idx, block in enumerate(platforms):
        platform = block.get("platform")
        prefix = f"platforms[{p_idx}]"
        if platform not in RULES:
            errors.append(f"{prefix}.platform 无效：{platform!r}")
            continue
        if platform in seen_platforms:
            errors.append(f"平台重复：{platform}")
        seen_platforms.add(platform)
        candidates = block.get("candidates")
        if not isinstance(candidates, list) or not candidates:
            errors.append(f"{prefix}.candidates 必须是非空数组")
            continue
        rec = block.get("recommended_index", 0)
        if not isinstance(rec, int) or not 0 <= rec < len(candidates):
            errors.append(f"{prefix}.recommended_index 越界")

        normalized_titles: set[str] = set()
        mechanisms: set[str] = set()
        for c_idx, candidate in enumerate(candidates):
            item = f"{prefix}.candidates[{c_idx}]"
            for field in ("title", "description", "tags", "mechanism", "evidence", "risk_notes"):
                if field not in candidate:
                    errors.append(f"{item} 缺少字段 {field}")
            title = candidate.get("title", "")
            desc = candidate.get("description", "")
            tags = candidate.get("tags", [])
            mechanism = candidate.get("mechanism", "")
            if not isinstance(title, str) or not title.strip():
                errors.append(f"{item}.title 不能为空")
                continue
            if not isinstance(desc, str) or not desc.strip():
                errors.append(f"{item}.description 不能为空")
            if not isinstance(tags, list) or not all(isinstance(tag, str) and tag.strip() for tag in tags):
                errors.append(f"{item}.tags 必须是非空字符串数组")
                tags = []
            compact = "".join(ch for ch in title.lower() if ch.isalnum())
            if compact in normalized_titles:
                errors.append(f"{item}.title 与同平台候选重复")
            normalized_titles.add(compact)
            if mechanism:
                mechanisms.add(mechanism)
            rule = RULES[platform]
            if text_len(title) > rule["title_max"]:
                warnings.append(f"{item}.title 长度 {text_len(title)}，超过建议检查线 {rule['title_max']}")
            if isinstance(desc, str) and text_len(desc) < rule["desc_min"]:
                warnings.append(f"{item}.description 可能过短")
            low, high = rule["tags"]
            if tags and not low <= len(tags) <= high:
                warnings.append(f"{item}.tags 数量 {len(tags)}，建议 {low}-{high}")
            combined = f"{title} {desc}"
            for term in RISKY:
                if term in combined:
                    warnings.append(f"{item} 含高风险绝对化词：{term}")

        if len(candidates) >= 4 and len(mechanisms) < 3:
            warnings.append(f"{prefix} 的标题机制不足 3 种")

    return errors, warnings


def main() -> int:
    if len(sys.argv) != 2:
        print("用法：python3 validate_output.py <output.json>")
        return 2
    errors, warnings = validate(Path(sys.argv[1]))
    for message in errors:
        print(f"ERROR: {message}")
    for message in warnings:
        print(f"WARNING: {message}")
    if not errors and not warnings:
        print("OK: 输出结构与基础规则检查通过")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
